#!/bin/bash
start(){

   python manage.py runserver 0.0.0.0:8000
   echo "1111"
}
start
